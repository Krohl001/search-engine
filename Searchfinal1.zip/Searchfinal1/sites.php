<?php 
include("connection.php");
class SitesSearch {

    public function getResults($search){

        global $conn;

        $query = $conn->prepare("SELECT COUNT(1) AS TotalCount FROM `crawled_websites` WHERE 
        website_url LIKE :search OR 
        website_title LIKE :search OR 
        website_keywords LIKE :search OR 
        website_description LIKE :search");

        $search = "%".$search."%";

        $query->bindParam("search",$search);
        $query->execute();

        $data = $query->fetch(PDO::FETCH_ASSOC);

        $count = $data["TotalCount"];

        $results = "<p class='searchCount'>About $count results</p>";

        $query1 = $conn->prepare("SELECT * FROM `crawled_websites` WHERE 
        website_url LIKE :search OR 
        website_title LIKE :search OR 
        website_keywords LIKE :search OR 
        website_description LIKE :search
        ORDER BY visits DESC
         ");       

        $query1->bindParam("search",$search);
        $query1->execute();

        $records ="<div class='site-results'>";

        while($row = $query1->fetch(PDO::FETCH_ASSOC)){
            $url = $row["website_url"];
            $id = $row["id"];
            $title = $row["website_title"];
            $description = $row["website_description"];
            $records .= "<div class='site-result-container' 
            <h3 class='title'>
            <a class = 'title-url' href='$url' data-id=$id>
            $title
            </a>
            </h3><br>
            <span style='color:green;font-size:16px' class='url'>$url</span><br>
            <span style='color:black;font-size:15px' class='description'>$description</span>            
            </div>";
        }
        $records .= "</div>";

        $results .=  $records;

        return array( $count,$results);
    }
}
?>