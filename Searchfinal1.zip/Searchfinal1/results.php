<?php

include("sites.php");
include("images.php");
include("connection.php");
if(isset($_GET['search']))
{
    $search = $_GET['search'];
}

    $type = isset($_GET["searchType"]) ? $_GET["searchType"] : 'sites';
    $page = isset($_GET["page"]) ? $_GET["page"] : 1;

?>
<!DOCTYPE html>
<html>
<head>

<title> SEARCH ENGINE</title>
<link rel="stylesheet" type="text/css" href="assets/style.css"/>
<link rel="stylesheet" type="text/css" href="assets/styles/div.css"/>
<link rel="stylesheet" href="assets/styles/min.css"/>
</head>
<body>
<form action="results.php" method="GET">
    <table border="0" width="100%" bgcolor="f2f2f2">
        <tr>
            <td width="10%">
                <a href="index.php"><img src ="assets/images/indexpic3.png" width = "100%"></a>
            </td>

            <td>
                <input value="<?php echo $search; ?>" type="text" name="search" id="searchfield" >
               <input type="submit" name="searchbtn" value ="GO!" id="gobtn">

            </td>
        </tr>
    </table>
</form>

    
            <div class="headerlist">
                <ul class="tablist">
                    <li class="<?php echo $type == 'sites' ? 'active' : ''?>">
                        <a href="<?php echo "results.php?search=$search&searchType=sites"?>">Sites</a>
                    </li>
                    <li class="<?php echo $type == 'images' ? 'active' : ''?>">
                        <a href="<?php echo "results.php?search=$search&searchType=images"?>">Images</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="resultsSection">
        <?php 
        $resultInstance = $type == 'images' ? new ImagesSearch() : new SitesSearch();
        $results = $resultInstance->getResults($search);

        echo $results[1];
        ?>
        </div>
        <script src="assets/scripts/jquery.js"></script>
        <script src="assets/scripts/min.js"></script>
        <script src="assets/scripts/pkgd.min.js"></script>
        <script src="assets/scripts/fancybox.min.js"></script>
        <script src="assets/scripts/script.js"></script>
    
</body>

</html>