<?php

include("connection.php");

if(isset($_POST["id"]) && isset($_POST["type"])) {
    $table = $_POST["type"];
    $query =  $conn->prepare("UPDATE $table SET visits = visits + 1 where id=:id");
    $query->bindParam(":id",$_POST["id"]);

    $query->execute();
}
?>