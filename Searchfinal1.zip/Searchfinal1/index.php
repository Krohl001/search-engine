<!DOCTYPE html>
<html>
<head>

<title> SEARCH ENGINE</title>
<link rel="stylesheet" type="text/css" href="assets/styles/style.css">
<style>
	body
	{
		background-image: url("assets/images/add6.jpg");
		color: white;
	}
</style>
</head>
<body>
<div class="main">
<br><br><br>
<center><img src="assets/images/indexpic1.jpg" width="35%"></center>
<div class="speak">
<form action="results.php" method="GET">
<br>
<input type="text" name="search" id ="speechtoText" placeholder="Please Speak to type" onclick="record()"></br></div>


<br><br>
<center><input type="submit" name="searchbtn" value ="SEARCH" id="searchbtn"></center>
</div>
<script>

function record()
{
	var recognition = new webkitSpeechRecognition();
	recognition.lang = "en-GB";
	recognition.onresult = function(event)
	{
		document.getElementById("speechtoText").value=event.results[0][0].transcript;
	}

	recognition.start();
}
</script>
</body>
</html>