<?php 
include("connection.php");
class ImagesSearch {

    public function getResults($search){

        global $conn;

        $query = $conn->prepare("SELECT COUNT(1) AS TotalCount FROM `images` WHERE 
        image_url LIKE :search OR 
        websitetitle LIKE :search OR 
        alt LIKE :search");

        $search = "%".$search."%";

        $query->bindParam("search",$search);
        $query->execute();

        $data = $query->fetch(PDO::FETCH_ASSOC);

        $count = $data["TotalCount"];

        $results = "<p class='searchCount'>About $count results</p>";
        $query1 = $conn->prepare("SELECT * FROM `images` WHERE 
        image_url LIKE :search OR 
        websitetitle LIKE :search OR 
        alt LIKE :search
        ORDER BY visits DESC
        ");        

        $query1->bindParam("search",$search);
        $query1->execute();

        $records ="<div class='images-results'>";

        while($row = $query1->fetch(PDO::FETCH_ASSOC)){
            $imageurl = $row["image_url"];
            $title = $row["websitetitle"];
            $id = $row["id"];
            if(!$title){
                $title = $row["alt"];
            }
            $records .= "<div class='image-result-container'>
            <a href='$imageurl' data-fancybox='image' data-caption='$title' data-id=$id>
            <img src='$imageurl'>
            </a>          
            </div>";
        }
        $records .= "</div>";

        $results .=  $records;

        return array( $count,$results);
    }
}
?>